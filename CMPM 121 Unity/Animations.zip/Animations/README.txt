Collect all 5 gems to open the door

Controls:  
move character forward or backward with  W or S
Rotate left or right with A or D
Left mouse button to attack with sword


Assets utilized:
Wood and Stone - Easy DG
Sci-Fi Door
Simple Gems Ultimate An.
Toon RTS Units-Demo 