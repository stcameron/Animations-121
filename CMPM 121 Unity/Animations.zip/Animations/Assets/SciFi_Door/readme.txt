This Asset pack contains model of a Sci-Fi Door.

This is a Sci-Fi themed door that is ready for your game.

Textures are in .PSD(diffuse, specular) and .PNG file format (normal), resolution are 1024 x 1024. 

They are all configured correctly for use with Unity, just import into your project.

Hope you like it!


